"""
Component Editor Dialog
=======================
UI for editing reliability fields per IEC TR 62380:
- Configurable EOS (interface type selection)
- Working time ratio (tau_on)
- Thermal expansion materials

Author:  Eliot Abramo
"""

import wx
import wx.lib.scrolledpanel as scrolled
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass

from .reliability_math import (
    get_component_types, get_field_definitions, calculate_component_lambda,
    reliability_from_lambda, INTERFACE_EOS_VALUES, THERMAL_EXPANSION_SUBSTRATE,
    IC_TYPE_CHOICES, IC_PACKAGE_CHOICES, DIODE_BASE_RATES, TRANSISTOR_BASE_RATES,
    CAPACITOR_PARAMS, RESISTOR_PARAMS, INDUCTOR_PARAMS, MISC_COMPONENT_RATES,
    OPTOCOUPLER_BASE_RATES, THYRISTOR_BASE_RATES, RELAY_PARAMS,
    CONNECTOR_PARAMS, PCB_SOLDER_PARAMS, DISCRETE_PACKAGE_TABLE,
    analyze_component_criticality,
)

@dataclass
class ComponentData:
    reference: str
    value: str
    component_type: str
    fields: Dict[str, Any]


def classify_component(reference: str, value: str, existing_fields: Dict[str, str] = None) -> str:
    """Classify component from reference designator.

    Mapping follows IEC TR 62380 component categories:
        R*  -> Resistor          (Section 12)
        C*  -> Capacitor         (Section 11)
        L*  -> Inductor          (Section 13)
        D*  -> Diode             (Section 9)
        Q*, T* -> Transistor     (Section 10)
        U*, IC* -> IC            (Section 8)
        K*  -> Relay             (Section 14)
        J*, P* -> Connector      (Section 15)
        Y*, X* -> Crystal/Osc    (Appendix)

    Args:
        reference:       Component reference designator (e.g. 'R1', 'U3').
        value:           Component value string (e.g. '10k', 'STM32F4').
        existing_fields: Optional dict with pre-assigned Reliability_Class.

    Returns:
        Component type string matching get_component_types() output.
    """
    ref = reference.upper()
    val = (value or "").lower()

    # Check user-assigned class first
    if existing_fields and existing_fields.get("Reliability_Class"):
        rc = existing_fields["Reliability_Class"].lower()
        if "ic" in rc or "integrated" in rc: return "Integrated Circuit"
        if "diode" in rc: return "Diode"
        if "transistor" in rc or "mosfet" in rc: return "Transistor"
        if "optocoupler" in rc or "opto" in rc: return "Optocoupler"
        if "thyristor" in rc or "triac" in rc or "scr" in rc: return "Thyristor/TRIAC"
        if "capacitor" in rc: return "Capacitor"
        if "resistor" in rc: return "Resistor"
        if "inductor" in rc or "transformer" in rc: return "Inductor/Transformer"
        if "relay" in rc: return "Relay"
        if "connector" in rc: return "Connector"
        if "pcb" in rc or "solder" in rc: return "PCB/Solder"

    # Value-based detection for ambiguous cases
    if "opto" in val or "optocoupler" in val:
        return "Optocoupler"
    if "triac" in val or "thyristor" in val or "scr" in val:
        return "Thyristor/TRIAC"
    if "relay" in val:
        return "Relay"

    # Reference designator mapping
    if ref.startswith('R'): return "Resistor"
    elif ref.startswith('C'): return "Capacitor"
    elif ref.startswith('L'): return "Inductor/Transformer"
    elif ref.startswith('D'): return "Diode"
    elif ref.startswith('Q') or ref.startswith('T'): return "Transistor"
    elif ref.startswith('U') or ref.startswith('IC'): return "Integrated Circuit"
    elif ref.startswith('K'): return "Relay"
    elif ref.startswith('J') or ref.startswith('P'): return "Connector"
    elif ref.startswith('Y') or ref.startswith('X'): return "Miscellaneous"
    return "Miscellaneous"


class FieldEditorPanel(scrolled.ScrolledPanel):
    """Panel for editing component fields with appropriate controls."""
    
    def __init__(self, parent, component_type: str, initial_values: Dict[str, Any] = None,
                 on_change: Callable = None):
        super().__init__(parent, style=wx.VSCROLL)
        self.component_type = component_type
        self.field_controls = {}
        self.on_change = on_change
        self._create_ui(initial_values or {})
        self.SetupScrolling(scroll_x=False)
    
    def _create_ui(self, initial_values: Dict[str, Any]):
        main_sizer = wx.BoxSizer(wx.VERTICAL)
        fields = get_field_definitions(self.component_type)
        
        # Group fields
        required = {k: v for k, v in fields.items() if v.get("required")}
        optional = {k: v for k, v in fields.items() if not v.get("required")}
        
        if required:
            box = wx.StaticBox(self, label="Required Fields")
            box_sizer = wx.StaticBoxSizer(box, wx.VERTICAL)
            for name, defn in required.items():
                ctrl = self._create_field(name, defn, initial_values)
                box_sizer.Add(ctrl, 0, wx.EXPAND | wx.ALL, 4)
            main_sizer.Add(box_sizer, 0, wx.EXPAND | wx.ALL, 5)
        
        if optional:
            box = wx.StaticBox(self, label="Optional / Environmental")
            box_sizer = wx.StaticBoxSizer(box, wx.VERTICAL)
            for name, defn in optional.items():
                ctrl = self._create_field(name, defn, initial_values)
                box_sizer.Add(ctrl, 0, wx.EXPAND | wx.ALL, 4)
            main_sizer.Add(box_sizer, 0, wx.EXPAND | wx.ALL, 5)
        
        self.SetSizer(main_sizer)
    
    def _create_field(self, name: str, defn: Dict, initial: Dict[str, Any]) -> wx.Sizer:
        sizer = wx.BoxSizer(wx.VERTICAL)
        
        # Label
        label_text = name.replace("_", " ").title()
        if defn.get("required"): label_text += " *"
        label = wx.StaticText(self, label=label_text)
        label.SetFont(label.GetFont().Bold())
        sizer.Add(label, 0, wx.LEFT, 2)
        
        # Help text
        help_text = defn.get("help", "")
        if help_text:
            help_lbl = wx.StaticText(self, label=help_text)
            help_lbl.SetForegroundColour(wx.Colour(100, 100, 100))
            font = help_lbl.GetFont()
            font.SetPointSize(font.GetPointSize() - 1)
            help_lbl.SetFont(font)
            sizer.Add(help_lbl, 0, wx.LEFT | wx.BOTTOM, 2)
        
        # Control
        ftype = defn.get("type", "text")
        default = defn.get("default")
        value = initial.get(name, default)
        
        if ftype == "choice":
            choices = defn.get("choices", [])
            ctrl = wx.ComboBox(self, choices=choices, style=wx.CB_DROPDOWN | wx.CB_READONLY)
            if value and value in choices: ctrl.SetValue(value)
            elif choices: ctrl.SetValue(choices[0])
            ctrl.Bind(wx.EVT_COMBOBOX, self._on_change)
        elif ftype == "bool":
            ctrl = wx.CheckBox(self, label="Yes")
            ctrl.SetValue(bool(value))
            ctrl.Bind(wx.EVT_CHECKBOX, self._on_change)
        elif ftype == "int":
            ctrl = wx.SpinCtrl(self, min=0, max=10000000, initial=int(value or 0))
            ctrl.Bind(wx.EVT_SPINCTRL, self._on_change)
        elif ftype == "float":
            ctrl = wx.SpinCtrlDouble(self, min=defn.get("min", 0), max=defn.get("max", 1000),
                                      initial=float(value or 0), inc=0.1)
            ctrl.SetDigits(3)
            ctrl.Bind(wx.EVT_SPINCTRLDOUBLE, self._on_change)
        else:
            ctrl = wx.TextCtrl(self, value=str(value or ""))
            ctrl.Bind(wx.EVT_TEXT, self._on_change)
        
        sizer.Add(ctrl, 0, wx.EXPAND | wx.LEFT | wx.RIGHT, 2)
        self.field_controls[name] = (ctrl, ftype, defn)
        return sizer
    
    def _on_change(self, event):
        if self.on_change: self.on_change()
        event.Skip()
    
    def get_values(self) -> Dict[str, Any]:
        values = {}
        for name, (ctrl, ftype, defn) in self.field_controls.items():
            try:
                if ftype == "choice": values[name] = ctrl.GetValue()
                elif ftype == "bool": values[name] = ctrl.GetValue()
                elif ftype == "int": values[name] = ctrl.GetValue()
                elif ftype == "float": values[name] = ctrl.GetValue()
                else: values[name] = ctrl.GetValue()
            except: values[name] = defn.get("default")
        return values
    
    def set_component_type(self, component_type: str, initial_values: Dict[str, Any] = None):
        self.component_type = component_type
        self.field_controls.clear()
        self.DestroyChildren()
        self._create_ui(initial_values or {})
        self.SetupScrolling(scroll_x=False)
        self.Layout()


class ComponentEditorDialog(wx.Dialog):
    """Dialog for editing reliability fields on a single component."""
    
    def __init__(self, parent, component: ComponentData, mission_hours: float = 43800):
        super().__init__(parent, title=f"Edit: {component.reference}",
                        size=(520, 650), style=wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER)
        self.component = component
        self.mission_hours = mission_hours
        self.result_fields = None
        self._create_ui()
        self._update_preview()
        self.Centre()
    
    def _create_ui(self):
        panel = wx.Panel(self)
        main = wx.BoxSizer(wx.VERTICAL)
        
        # Header
        header = wx.BoxSizer(wx.HORIZONTAL)
        ref_lbl = wx.StaticText(panel, label=f"Reference: {self.component.reference}")
        ref_lbl.SetFont(ref_lbl.GetFont().Bold())
        header.Add(ref_lbl, 0, wx.ALL, 5)
        val_lbl = wx.StaticText(panel, label=f"Value: {self.component.value}")
        header.Add(val_lbl, 0, wx.ALL, 5)
        main.Add(header, 0, wx.EXPAND)
        
        # Type selector
        type_sizer = wx.BoxSizer(wx.HORIZONTAL)
        type_sizer.Add(wx.StaticText(panel, label="Component Type:"), 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 5)
        self.type_combo = wx.ComboBox(panel, choices=get_component_types(), style=wx.CB_READONLY)
        self.type_combo.SetValue(self.component.component_type)
        self.type_combo.Bind(wx.EVT_COMBOBOX, self._on_type_change)
        type_sizer.Add(self.type_combo, 1, wx.ALL | wx.EXPAND, 5)
        main.Add(type_sizer, 0, wx.EXPAND)
        
        main.Add(wx.StaticLine(panel), 0, wx.EXPAND | wx.ALL, 5)
        
        # --- Lambda Override Box ---
        ovr_box = wx.StaticBox(panel, label="Lambda Override (use measured / datasheet value)")
        ovr_sizer = wx.StaticBoxSizer(ovr_box, wx.VERTICAL)
        ovr_row = wx.BoxSizer(wx.HORIZONTAL)
        self.override_cb = wx.CheckBox(panel, label="Override calculated lambda with fixed value")
        self.override_cb.SetToolTip(
            "When checked, the plugin uses your specified FIT value directly\n"
            "instead of computing it from the IEC TR 62380 model.\n"
            "Use this for components with manufacturer-provided failure rates,\n"
            "FIDES data, or field-measured reliability figures.")
        init_override = self.component.fields.get("override_lambda")
        self.override_cb.SetValue(init_override is not None)
        self.override_cb.Bind(wx.EVT_CHECKBOX, self._on_override_toggle)
        ovr_row.Add(self.override_cb, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 4)
        ovr_sizer.Add(ovr_row, 0, wx.EXPAND)
        
        ovr_val_row = wx.BoxSizer(wx.HORIZONTAL)
        ovr_val_row.Add(wx.StaticText(panel, label="Fixed Lambda:"), 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 4)
        self.override_val = wx.SpinCtrlDouble(panel, min=0, max=1e9, initial=float(init_override or 0),
                                               inc=0.1, size=(120, -1))
        self.override_val.SetDigits(3)
        self.override_val.Enable(init_override is not None)
        self.override_val.Bind(wx.EVT_SPINCTRLDOUBLE, lambda e: self._update_preview())
        ovr_val_row.Add(self.override_val, 0, wx.ALL, 4)
        ovr_val_row.Add(wx.StaticText(panel, label="FIT"), 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 4)
        ovr_help = wx.StaticText(panel, label="(1 FIT = 1 failure per 10^9 hours)")
        ovr_help.SetForegroundColour(wx.Colour(100, 100, 100))
        ovr_val_row.Add(ovr_help, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 4)
        ovr_sizer.Add(ovr_val_row, 0, wx.EXPAND)
        main.Add(ovr_sizer, 0, wx.EXPAND | wx.ALL, 5)
        
        # Field editor
        self.field_panel = FieldEditorPanel(panel, self.component.component_type,
                                            self.component.fields, on_change=self._update_preview)
        main.Add(self.field_panel, 1, wx.EXPAND | wx.ALL, 5)
        
        # Preview
        preview_box = wx.StaticBox(panel, label="Calculated Results")
        preview_sizer = wx.StaticBoxSizer(preview_box, wx.VERTICAL)
        self.preview = wx.TextCtrl(panel, style=wx.TE_MULTILINE | wx.TE_READONLY, size=(-1, 80))
        self.preview.SetBackgroundColour(wx.Colour(245, 245, 245))
        preview_sizer.Add(self.preview, 1, wx.EXPAND | wx.ALL, 5)
        main.Add(preview_sizer, 0, wx.EXPAND | wx.ALL, 5)
        
        # Buttons
        btn_sizer = wx.StdDialogButtonSizer()
        ok_btn = wx.Button(panel, wx.ID_OK, "Apply")
        ok_btn.Bind(wx.EVT_BUTTON, self._on_ok)
        btn_sizer.AddButton(ok_btn)
        btn_sizer.AddButton(wx.Button(panel, wx.ID_CANCEL, "Cancel"))
        btn_sizer.Realize()
        main.Add(btn_sizer, 0, wx.EXPAND | wx.ALL, 10)
        
        panel.SetSizer(main)
    
    def _on_type_change(self, event):
        self.field_panel.set_component_type(self.type_combo.GetValue(), {})
        self._update_preview()
    
    def _on_override_toggle(self, event):
        enabled = self.override_cb.GetValue()
        self.override_val.Enable(enabled)
        self.field_panel.Enable(not enabled)
        self._update_preview()
    
    def _update_preview(self):
        try:
            # Check override first
            if self.override_cb.GetValue():
                fit = self.override_val.GetValue()
                lam = fit * 1e-9
                r = reliability_from_lambda(lam, self.mission_hours)
                mttf_h = 1 / lam if lam > 0 else float('inf')
                mttf_y = mttf_h / 8760
                text = f"[OVERRIDE] lambda = {fit:.2f} FIT ({lam:.2e} /h)\n"
                text += f"R({self.mission_hours/8760:.1f} yr): {r:.6f} ({r*100:.4f}%)\n"
                text += f"MTTF: {mttf_y:.1f} years"
                self.preview.SetValue(text)
                return

            ct = self.type_combo.GetValue()
            params = self.field_panel.get_values()
            result = calculate_component_lambda(ct, params)
            lam = result.get("lambda_total", 0)
            fit = result.get("fit_total", lam * 1e9)
            r = reliability_from_lambda(lam, self.mission_hours)
            mttf_h = 1 / lam if lam > 0 else float('inf')
            mttf_y = mttf_h / 8760
            
            text = f"lambda (failure rate): {fit:.2f} FIT ({lam:.2e} /h)\n"
            text += f"R({self.mission_hours/8760:.1f} yr): {r:.6f} ({r*100:.4f}%)\n"
            text += f"MTTF: {mttf_y:.1f} years"
            
            # Show EOS contribution if applicable
            if result.get("lambda_eos", 0) > 0:
                eos_fit = result["lambda_eos"] * 1e9
                text += f"\n(includes {eos_fit:.1f} FIT from EOS)"
            
            self.preview.SetValue(text)
        except Exception as e:
            self.preview.SetValue(f"Error: {e}")
    
    def _on_ok(self, event):
        self.result_fields = self.field_panel.get_values()
        self.result_fields["_component_type"] = self.type_combo.GetValue()
        if self.override_cb.GetValue():
            self.result_fields["override_lambda"] = self.override_val.GetValue()
        else:
            self.result_fields["override_lambda"] = None
        self.EndModal(wx.ID_OK)
    
    def get_result(self) -> Optional[Dict[str, Any]]:
        return self.result_fields


class BatchComponentEditorDialog(wx.Dialog):
    """Dialog for editing multiple components at once."""
    
    def __init__(self, parent, components: List[ComponentData], mission_hours: float = 43800):
        super().__init__(parent, title="Batch Component Editor",
                        size=(950, 700), style=wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER)
        self.components = components
        self.mission_hours = mission_hours
        self.results = {}
        self._create_ui()
        self.Centre()
    
    def _create_ui(self):
        panel = wx.Panel(self)
        main = wx.BoxSizer(wx.HORIZONTAL)
        
        # Left: component list
        left = wx.Panel(panel)
        left_sizer = wx.BoxSizer(wx.VERTICAL)
        left_sizer.Add(wx.StaticText(left, label="Components:"), 0, wx.ALL, 5)
        
        self.list = wx.ListCtrl(left, style=wx.LC_REPORT | wx.LC_SINGLE_SEL)
        self.list.InsertColumn(0, "Ref", width=60)
        self.list.InsertColumn(1, "Value", width=80)
        self.list.InsertColumn(2, "Type", width=120)
        self.list.InsertColumn(3, "Lambda (FIT)", width=80)
        self.list.InsertColumn(4, "Source", width=60)
        
        for i, comp in enumerate(self.components):
            self.list.InsertItem(i, comp.reference)
            self.list.SetItem(i, 1, comp.value or "")
            self.list.SetItem(i, 2, comp.component_type)
            ovr = comp.fields.get("override_lambda")
            if ovr is not None:
                self.list.SetItem(i, 3, f"{ovr:.1f}")
                self.list.SetItem(i, 4, "OVR")
            else:
                try:
                    result = calculate_component_lambda(comp.component_type, comp.fields)
                    self.list.SetItem(i, 3, f"{result.get('fit_total', 0):.1f}")
                except:
                    self.list.SetItem(i, 3, "?")
                self.list.SetItem(i, 4, "Calc")
        
        self.list.Bind(wx.EVT_LIST_ITEM_SELECTED, self._on_select)
        self.list.Bind(wx.EVT_LIST_ITEM_ACTIVATED, self._on_edit)
        left_sizer.Add(self.list, 1, wx.EXPAND | wx.ALL, 5)
        
        btn_row = wx.BoxSizer(wx.HORIZONTAL)
        edit_btn = wx.Button(left, label="Edit Selected...")
        edit_btn.Bind(wx.EVT_BUTTON, self._on_edit)
        btn_row.Add(edit_btn, 1, wx.ALL, 3)
        auto_btn = wx.Button(left, label="Auto-Classify All")
        auto_btn.Bind(wx.EVT_BUTTON, self._on_auto)
        btn_row.Add(auto_btn, 1, wx.ALL, 3)
        left_sizer.Add(btn_row, 0, wx.EXPAND)
        
        left.SetSizer(left_sizer)
        main.Add(left, 1, wx.EXPAND | wx.ALL, 5)
        
        # Right: quick edit panel
        right = wx.Panel(panel)
        right_sizer = wx.BoxSizer(wx.VERTICAL)
        right_sizer.Add(wx.StaticText(right, label="Quick Edit:"), 0, wx.ALL, 5)
        
        type_row = wx.BoxSizer(wx.HORIZONTAL)
        type_row.Add(wx.StaticText(right, label="Type:"), 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 3)
        self.type_combo = wx.ComboBox(right, choices=get_component_types(), style=wx.CB_READONLY)
        self.type_combo.Bind(wx.EVT_COMBOBOX, self._on_quick_type)
        type_row.Add(self.type_combo, 1, wx.ALL, 3)
        right_sizer.Add(type_row, 0, wx.EXPAND)
        
        # --- Lambda Override Box in Quick Edit ---
        ovr_box = wx.StaticBox(right, label="Lambda Override")
        ovr_sizer = wx.StaticBoxSizer(ovr_box, wx.VERTICAL)
        self.quick_override_cb = wx.CheckBox(right, label="Override with fixed FIT value")
        self.quick_override_cb.SetToolTip(
            "Use a manufacturer-provided or measured failure rate\n"
            "instead of the IEC TR 62380 model.")
        self.quick_override_cb.Bind(wx.EVT_CHECKBOX, self._on_quick_override_toggle)
        ovr_sizer.Add(self.quick_override_cb, 0, wx.ALL, 4)
        ovr_val_row = wx.BoxSizer(wx.HORIZONTAL)
        ovr_val_row.Add(wx.StaticText(right, label="Lambda:"), 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 4)
        self.quick_override_val = wx.SpinCtrlDouble(right, min=0, max=1e9, initial=0, inc=0.1, size=(100, -1))
        self.quick_override_val.SetDigits(3)
        self.quick_override_val.Enable(False)
        ovr_val_row.Add(self.quick_override_val, 0, wx.ALL, 4)
        ovr_val_row.Add(wx.StaticText(right, label="FIT"), 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 4)
        ovr_sizer.Add(ovr_val_row, 0, wx.EXPAND)
        right_sizer.Add(ovr_sizer, 0, wx.EXPAND | wx.ALL, 5)
        
        self.field_panel = FieldEditorPanel(right, "Resistor", {}, None)
        right_sizer.Add(self.field_panel, 1, wx.EXPAND | wx.ALL, 5)
        
        apply_btn = wx.Button(right, label="Apply to Selected")
        apply_btn.Bind(wx.EVT_BUTTON, self._on_apply_quick)
        right_sizer.Add(apply_btn, 0, wx.EXPAND | wx.ALL, 5)
        
        right.SetSizer(right_sizer)
        main.Add(right, 1, wx.EXPAND | wx.ALL, 5)
        
        panel.SetSizer(main)
        
        # Dialog buttons
        dlg_sizer = wx.BoxSizer(wx.VERTICAL)
        dlg_sizer.Add(panel, 1, wx.EXPAND)
        btn_sizer = wx.StdDialogButtonSizer()
        ok_btn = wx.Button(self, wx.ID_OK, "Save All")
        ok_btn.Bind(wx.EVT_BUTTON, self._on_ok)
        btn_sizer.AddButton(ok_btn)
        btn_sizer.AddButton(wx.Button(self, wx.ID_CANCEL, "Cancel"))
        btn_sizer.Realize()
        dlg_sizer.Add(btn_sizer, 0, wx.EXPAND | wx.ALL, 10)
        self.SetSizer(dlg_sizer)
        
        if self.components:
            self.list.Select(0)
            self._load_component(0)
    
    def _on_select(self, event):
        self._load_component(event.GetIndex())
    
    def _load_component(self, idx: int):
        if 0 <= idx < len(self.components):
            comp = self.components[idx]
            fields = self.results.get(comp.reference, comp.fields)
            ct = fields.get("_component_type", comp.component_type)
            self.type_combo.SetValue(ct)
            self.field_panel.set_component_type(ct, fields)
            # Populate override controls
            ovr = fields.get("override_lambda")
            if ovr is not None:
                self.quick_override_cb.SetValue(True)
                self.quick_override_val.SetValue(float(ovr))
                self.quick_override_val.Enable(True)
                self.field_panel.Enable(False)
            else:
                self.quick_override_cb.SetValue(False)
                self.quick_override_val.SetValue(0.0)
                self.quick_override_val.Enable(False)
                self.field_panel.Enable(True)
    
    def _on_quick_type(self, event):
        self.field_panel.set_component_type(self.type_combo.GetValue(), {})
    
    def _on_quick_override_toggle(self, event):
        enabled = self.quick_override_cb.GetValue()
        self.quick_override_val.Enable(enabled)
        self.field_panel.Enable(not enabled)
    
    def _on_apply_quick(self, event):
        idx = self.list.GetFirstSelected()
        if idx < 0: return
        comp = self.components[idx]
        fields = self.field_panel.get_values()
        fields["_component_type"] = self.type_combo.GetValue()
        # Handle override from quick edit panel
        if self.quick_override_cb.GetValue():
            fields["override_lambda"] = self.quick_override_val.GetValue()
        else:
            fields["override_lambda"] = None
        self.results[comp.reference] = fields
        comp.component_type = self.type_combo.GetValue()
        comp.fields = fields
        self.list.SetItem(idx, 2, comp.component_type)
        ovr = fields.get("override_lambda")
        if ovr is not None:
            self.list.SetItem(idx, 3, f"{ovr:.1f}")
            self.list.SetItem(idx, 4, "OVR")
        else:
            try:
                result = calculate_component_lambda(comp.component_type, fields)
                self.list.SetItem(idx, 3, f"{result.get('fit_total', 0):.1f}")
            except:
                self.list.SetItem(idx, 3, "?")
            self.list.SetItem(idx, 4, "Calc")
    
    def _on_edit(self, event):
        idx = self.list.GetFirstSelected()
        if idx < 0:
            wx.MessageBox("Select a component first.", "No Selection", wx.OK | wx.ICON_INFORMATION)
            return
        comp = self.components[idx]
        fields = self.results.get(comp.reference, comp.fields)
        ct = fields.get("_component_type", comp.component_type)
        edit_comp = ComponentData(reference=comp.reference, value=comp.value,
                                  component_type=ct, fields=fields)
        dlg = ComponentEditorDialog(self, edit_comp, self.mission_hours)
        if dlg.ShowModal() == wx.ID_OK:
            result = dlg.get_result()
            if result:
                self.results[comp.reference] = result
                comp.component_type = result.get("_component_type", comp.component_type)
                comp.fields = result
                self.list.SetItem(idx, 2, comp.component_type)
                ovr = result.get("override_lambda")
                if ovr is not None:
                    self.list.SetItem(idx, 3, f"{ovr:.1f}")
                    self.list.SetItem(idx, 4, "OVR")
                else:
                    try:
                        calc = calculate_component_lambda(comp.component_type, result)
                        self.list.SetItem(idx, 3, f"{calc.get('fit_total', 0):.1f}")
                    except:
                        self.list.SetItem(idx, 3, "?")
                    self.list.SetItem(idx, 4, "Calc")
                self._load_component(idx)
        dlg.Destroy()
    
    def _on_auto(self, event):
        for i, comp in enumerate(self.components):
            if comp.reference not in self.results:
                new_type = classify_component(comp.reference, comp.value, comp.fields)
                comp.component_type = new_type
                self.list.SetItem(i, 2, new_type)
                try:
                    result = calculate_component_lambda(new_type, comp.fields)
                    self.list.SetItem(i, 3, f"{result.get('fit_total', 0):.1f}")
                except:
                    self.list.SetItem(i, 3, "?")
    
    def _on_ok(self, event):
        # Auto-apply the currently visible quick-edit panel state for the
        # selected component so the user doesn't need to click "Apply" first.
        idx = self.list.GetFirstSelected()
        if 0 <= idx < len(self.components):
            comp = self.components[idx]
            fields = self.field_panel.get_values()
            fields["_component_type"] = self.type_combo.GetValue()
            if self.quick_override_cb.GetValue():
                fields["override_lambda"] = self.quick_override_val.GetValue()
            else:
                fields["override_lambda"] = None
            self.results[comp.reference] = fields

        # For components never explicitly edited, preserve their current fields
        for comp in self.components:
            if comp.reference not in self.results:
                fields = comp.fields.copy()
                fields["_component_type"] = comp.component_type
                self.results[comp.reference] = fields
        self.EndModal(wx.ID_OK)
    
    def get_results(self) -> Dict[str, Dict[str, Any]]:
        return self.results


class QuickReferenceDialog(wx.Dialog):
    """IEC TR 62380 quick reference."""
    
    def __init__(self, parent):
        super().__init__(parent, title="IEC TR 62380 Quick Reference",
                        size=(650, 550), style=wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER)
        
        nb = wx.Notebook(self)
        
        # Overview tab
        overview = wx.TextCtrl(nb, style=wx.TE_MULTILINE | wx.TE_READONLY)
        overview.SetValue("""IEC TR 62380 - Reliability Data Handbook
=========================================

Key Concepts:
 Lambda: Failure rate in FIT (Failures In Time = failures per 10^9 hours)
 R(t): Reliability = probability of survival = exp(-lambda * t)
 MTTF: Mean Time To Failure = 1 / lambda

General Model:
lambda_component = (lambda_die + lambda_package + lambda_EOS) * 10^-9 /h

Temperature Factor (Arrhenius):
pi_t = exp(Ea * (1/T_ref - 1/(273 + T_j)))

Thermal Cycling Factor pi_n:
 n <= 8760: pi_n = n^0.76
 n >  8760: pi_n = 1.7 * n^0.6

Working Time Ratio (tau_on):
 Scales die contribution for duty-cycled operation
 tau_on = 1.0 for continuous operation
 tau_on = 0.5 for 50% duty cycle

EOS (Electrical Overstress):
 Interface circuits add lambda_EOS based on environment type
 Computer: 10 FIT, Telecom: 15-70 FIT, Avionics: 20 FIT
 Power Supply: 40 FIT, Space: 25-35 FIT
""")
        nb.AddPage(overview, "Overview")
        
        # EOS tab
        eos = wx.TextCtrl(nb, style=wx.TE_MULTILINE | wx.TE_READONLY)
        eos_text = "EOS (Electrical Overstress) Values\n" + "="*40 + "\n\n"
        eos_text += f"{'Interface Type':<25} {'lambda_EOS (FIT)':<15}\n"
        eos_text += "-"*40 + "\n"
        for name, vals in INTERFACE_EOS_VALUES.items():
            eos_text += f"{name:<25} {vals['l_eos']:<15}\n"
        eos.SetValue(eos_text)
        nb.AddPage(eos, "EOS Values")
        
        # Materials tab
        mat = wx.TextCtrl(nb, style=wx.TE_MULTILINE | wx.TE_READONLY)
        mat_text = "Thermal Expansion Coefficients (ppm/degC)\n" + "="*45 + "\n\n"
        mat_text += "SUBSTRATES:\n"
        for name, cte in THERMAL_EXPANSION_SUBSTRATE.items():
            mat_text += f"  {name:<30} alpha = {cte}\n"
        mat_text += "\nPACKAGES (alpha_C):\n"
        mat_text += "  Epoxy (Plastic package)          = 21.5\n"
        mat_text += "  Alumina (Ceramic package)        = 6.5\n"
        mat_text += "  Kovar (Metallic package)         = 5.0\n"
        mat_text += "  Bare Die / Flip Chip             = 2.6\n"
        mat.SetValue(mat_text)
        nb.AddPage(mat, "Materials")
        
        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(nb, 1, wx.EXPAND | wx.ALL, 5)
        close_btn = wx.Button(self, wx.ID_CLOSE, "Close")
        close_btn.Bind(wx.EVT_BUTTON, lambda e: self.EndModal(wx.ID_CLOSE))
        sizer.Add(close_btn, 0, wx.ALIGN_CENTER | wx.ALL, 10)
        self.SetSizer(sizer)
        self.Centre()
